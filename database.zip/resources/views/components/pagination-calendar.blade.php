<div class="pagination4 grid grid-cols-3 gap-2 sm:flex sm:justify-center mt-5">
    <!-- Previous Button -->
    <a href="{{ url()->current() . '?calendar-page=' . ($data->currentPage() - 1) }}" 
        class="prev col-span-3 min-w-max sm:col-auto inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md 
        hover:bg-gray-100 @if($data->onFirstPage()) opacity-50 cursor-not-allowed @endif">
        &laquo; Prev
    </a>

    <!-- Page Numbers with Horizontal Scrolling -->
    <div class="page-numbers-wrapper col-span-3 sm:col-auto overflow-x-auto flex space-x-2 py-2">
        @for ($i = 1; $i <= $data->lastPage(); $i++)
            <a href="{{ url()->current() . '?calendar-page=' . $i }}" 
               class="page-link inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-gray-700 border rounded-md 
               @if($i == $data->currentPage()) bg-blue-500 text-white border-blue-500 @else bg-white border-gray-300 hover:bg-gray-100 @endif">
                {{ $i }}
            </a>
        @endfor
    </div>

    <!-- Next Button -->
    <a href="{{ url()->current() . '?calendar-page=' . ($data->currentPage() + 1) }}" 
        class="next col-span-3 min-w-max sm:col-auto inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md 
        hover:bg-gray-100 @if(!$data->hasMorePages()) opacity-50 cursor-not-allowed @endif">
        Next &raquo;
    </a>    
</div>

<style>
/* Ensure smooth horizontal scrolling */
.page-numbers-wrapper {
    scrollbar-width: thin; /* For Firefox */
}
.page-numbers-wrapper::-webkit-scrollbar {
    height: 3px;
}
.page-numbers-wrapper::-webkit-scrollbar-thumb {
    background-color: #ccc;
    border-radius: 5px;
}
.page-numbers-wrapper::-webkit-scrollbar-track {
    background-color: #f4f4f4;
}
</style>
