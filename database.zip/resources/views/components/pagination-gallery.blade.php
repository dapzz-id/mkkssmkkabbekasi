@php
    $current = $data->currentPage();
    $last = $data->lastPage();
    $total = $data->total();
    $firstItem = $data->firstItem() ?? 0;
    $lastItem = $data->lastItem() ?? 0;

    $range = 2;
    $start = max(1, $current - $range);
    $end = min($last, $current + $range);

    function pageUrl($page) {
        return request()->fullUrlWithQuery(['gallery-page' => $page]);
    }

    $prevPage = max(1, $current - 1);
    $nextPage = min($last, $current + 1);
@endphp

<div class="flex flex-col sm:flex-row items-center justify-between gap-4 px-4 sm:px-6 py-4 border-t border-slate-100 bg-white">
    <!-- Left: Data Count Info -->
    <div class="text-xs sm:text-sm text-slate-500 font-medium order-2 sm:order-1 text-center sm:text-left">
        Menampilkan <span class="font-semibold text-slate-700">{{ $firstItem }}</span> - <span class="font-semibold text-slate-700">{{ $lastItem }}</span> dari <span class="font-semibold text-slate-700">{{ $total }}</span> data
    </div>

    <!-- Center: Page Controls -->
    <div class="flex items-center gap-1 sm:gap-1.5 order-1 sm:order-2 pagination-gallery">
        {{-- Previous Button --}}
        @if ($data->onFirstPage())
            <span class="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-400 cursor-not-allowed select-none">
                &lsaquo; Sebelumnya
            </span>
        @else
            <a href="{{ pageUrl($prevPage) }}"
               class="page-link inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors"
               aria-label="Halaman Sebelumnya">
                &lsaquo; Sebelumnya
            </a>
        @endif

        {{-- First Page if out of range --}}
        @if ($start > 1)
            <a href="{{ pageUrl(1) }}"
               class="page-link w-8 h-8 rounded-lg text-xs font-semibold flex items-center justify-center transition-colors text-slate-700 hover:bg-slate-100"
               aria-label="Halaman 1">
                1
            </a>
            @if ($start > 2)
                <span class="text-slate-400 text-xs px-1">…</span>
            @endif
        @endif

        {{-- Page Numbers --}}
        @for ($i = $start; $i <= $end; $i++)
            @if ($i == $current)
                <span class="w-8 h-8 rounded-lg text-xs font-bold flex items-center justify-center bg-blue-600 text-white shadow-xs select-none">
                    {{ $i }}
                </span>
            @else
                <a href="{{ pageUrl($i) }}"
                   class="page-link w-8 h-8 rounded-lg text-xs font-semibold flex items-center justify-center transition-colors text-slate-700 hover:bg-slate-100"
                   aria-label="Halaman {{ $i }}">
                    {{ $i }}
                </a>
            @endif
        @endfor

        {{-- Last Page if out of range --}}
        @if ($end < $last)
            @if ($end < $last - 1)
                <span class="text-slate-400 text-xs px-1">…</span>
            @endif
            <a href="{{ pageUrl($last) }}"
               class="page-link w-8 h-8 rounded-lg text-xs font-semibold flex items-center justify-center transition-colors text-slate-700 hover:bg-slate-100"
               aria-label="Halaman {{ $last }}">
                {{ $last }}
            </a>
        @endif

        {{-- Next Button --}}
        @if ($data->hasMorePages())
            <a href="{{ pageUrl($nextPage) }}"
               class="page-link inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors"
               aria-label="Halaman Berikutnya">
                Berikutnya &rsaquo;
            </a>
        @else
            <span class="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-400 cursor-not-allowed select-none">
                Berikutnya &rsaquo;
            </span>
        @endif
    </div>

    <!-- Right: Page Size / Per Halaman Label -->
    <div class="hidden md:flex items-center gap-1.5 text-xs text-slate-500 order-3">
        <div class="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 shadow-2xs flex items-center gap-1">
            <span>{{ $data->perPage() }}</span>
            <svg class="w-3 h-3 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
        </div>
        <span>per halaman</span>
    </div>
</div>
