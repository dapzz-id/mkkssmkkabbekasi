<!-- Footer -->
<footer class="footer" style="margin-top: 100px;">
    <div class="py-2 running-text">
        <div class="running-text-container">
            @php
                $recentContent = DB::table('konten')
                    ->orderBy('tanggal_upload', 'desc')
                    ->take(3)
                    ->select('judul')
                    ->get();
            @endphp

            <div class="running-text-content">
                @if($recentContent->count() > 0)
                    @foreach($recentContent as $content)
                        <span class="running-text-item">{{ $content->judul }} &bull; </span>
                    @endforeach
                @else
                    <span class="running-text-item">Selamat datang di website MKKS SMK Kab Bekasi</span>
                @endif
            </div>
        </div>
    </div>

    <div class="py-4 footer-content">
        <div class="container">
            <div class="row justify-content-center align-items-center">
                @php
                    $sponsor = DB::table('sponsor')->get();
                @endphp

                <!-- Sponsor Images -->
                <div class="flex-wrap gap-4 mb-4 sponsor-wrapper d-flex justify-content-center">
                    @foreach($sponsor as $item)
                        <div class="sponsor-item">
                            <img data-src="{{ $item->url_image }}" height="60" title="{{$item->nama}}" alt="{{ $item->nama }}" class="lazyload sponsor-image">
                        </div>
                    @endforeach
                </div>

                <!-- Copyright -->
                <div class="text-center col-12">
                    <p class="mb-0 copyright">&copy; 2024 - MKKS SMK KAB BEKASI | All Right Reserved</p>
                </div>
            </div>
        </div>
    </div>
</footer>
