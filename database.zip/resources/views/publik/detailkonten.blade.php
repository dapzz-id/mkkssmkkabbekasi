@extends('publik.layouts.main')

@section('container')
    <style>
        /* Carousel Styling */
        .media-carousel {
            position: relative;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
            margin: 2.5rem 0;
            background: #fff;
            border: 1px solid #e9ecef;
        }

        .carousel-inner {
            border-radius: 16px;
            overflow: hidden;
            position: relative;
            height: 600px;
        }

        .carousel-item {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 0.6s ease-in-out;
            background: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1;
            padding: 40px;
        }

        .carousel-item.active {
            opacity: 1;
            z-index: 2;
        }

        .carousel-item img,
        .carousel-item video {
            max-width: 90%;
            max-height: 90%;
            object-fit: contain;
            display: block;
            width: auto;
            height: auto;
        }

        /* Specific styling for vertical images */
        .carousel-item img[data-orientation="vertical"] {
            max-height: 90%;
            max-width: 80%;
        }

        /* Specific styling for horizontal images */
        .carousel-item img[data-orientation="horizontal"] {
            max-width: 90%;
            max-height: 80%;
        }

        .carousel-item video {
            background: transparent;
            max-width: 90%;
            max-height: 90%;
            cursor: pointer;
        }

        .carousel-control-prev,
        .carousel-control-next {
            width: 60px;
            height: 60px;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 50%;
            top: 50%;
            transform: translateY(-50%);
            opacity: 0.9;
            transition: all 0.3s ease;
            margin: 0 20px;
            border: 1px solid #dee2e6;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            position: absolute;
            z-index: 3;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #495057;
            text-decoration: none;
            font-size: 1.5rem;
        }

        .carousel-control-prev {
            left: 0;
        }

        .carousel-control-next {
            right: 0;
        }

        .carousel-control-prev:hover,
        .carousel-control-next:hover {
            background: white;
            opacity: 1;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            transform: translateY(-50%) scale(1.05);
        }

        .carousel-indicators {
            position: absolute;
            bottom: 20px;
            left: 0;
            right: 0;
            display: flex;
            justify-content: center;
            gap: 10px;
            z-index: 3;
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .carousel-indicators button {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            border: 2px solid #adb5bd;
            background: transparent;
            opacity: 1;
            transition: all 0.3s ease;
            cursor: pointer;
            padding: 0;
            margin: 0;
        }

        .carousel-indicators button.active {
            background: #6c757d;
            border-color: #6c757d;
            transform: scale(1.3);
        }

        .carousel-caption {
            position: absolute;
            bottom: 20px;
            left: 0;
            right: 0;
            text-align: center;
            z-index: 3;
        }

        .carousel-caption .media-counter {
            font-size: 0.9rem;
            color: #495057;
            background: rgba(255, 255, 255, 0.95);
            padding: 6px 16px;
            border-radius: 25px;
            display: inline-block;
            border: 1px solid #dee2e6;
            font-weight: 600;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .media-play-btn {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 70px;
            height: 70px;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 50%;
            border: none;
            color: #495057;
            font-size: 2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            opacity: 0.95;
            transition: all 0.3s ease;
            z-index: 4;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            border: 1px solid #dee2e6;
        }

        .media-play-btn:hover {
            background: white;
            transform: translate(-50%, -50%) scale(1.15);
            opacity: 1;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
        }

        .media-play-btn.hidden {
            display: none;
        }

        /* Fullscreen Video Modal */
        .video-fullscreen-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.95);
            z-index: 9999;
            opacity: 0;
            transition: opacity 0.3s ease;
            align-items: center;
            justify-content: center;
        }

        .video-fullscreen-modal.active {
            display: flex;
            opacity: 1;
        }

        .video-fullscreen-container {
            position: relative;
            width: 95%;
            height: 95%;
            display: flex;
            flex-direction: column;
        }

        .video-fullscreen-header {
            display: flex;
            justify-content: flex-end;
            padding: 20px;
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            z-index: 2;
        }

        .video-close-btn {
            width: 50px;
            height: 50px;
            background: rgba(255, 255, 255, 0.1);
            border: none;
            border-radius: 50%;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .video-close-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: scale(1.1);
        }

        .video-fullscreen-player {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .video-fullscreen-player video {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        /* Video Controls */
        .video-controls {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            opacity: 0;
            transition: opacity 0.3s ease;
            z-index: 2;
        }

        .video-fullscreen-container:hover .video-controls {
            opacity: 1;
        }

        .video-progress {
            width: 100%;
            height: 6px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 3px;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        .video-progress-bar {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            background: #0d6efd;
            border-radius: 3px;
            width: 0%;
            transition: width 0.1s linear;
        }

        .video-progress-time {
            display: flex;
            justify-content: space-between;
            color: white;
            font-size: 0.9rem;
            margin-top: 5px;
        }

        .video-control-buttons {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .video-control-btn {
            background: transparent;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            padding: 5px;
            transition: all 0.3s ease;
        }

        .video-control-btn:hover {
            color: #0d6efd;
            transform: scale(1.1);
        }

        .video-volume-control {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-left: auto;
        }

        .video-volume-slider {
            width: 80px;
            height: 4px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 2px;
            cursor: pointer;
            position: relative;
        }

        .video-volume-level {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            background: white;
            border-radius: 2px;
            width: 100%;
        }

        .video-fullscreen-btn {
            margin-left: 20px;
        }

        /* Article Styling */
        .article-container {
            padding: 2rem 0;
            background: linear-gradient(to bottom, #f8f9fa 0%, #ffffff 100px);
            min-height: 100vh;
        }

        .article-header {
            padding: 1.5rem;
            background: white;
            border-radius: 16px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
        }

        .category-badge {
            display: inline-block;
        }

        .category-badge .badge {
            font-size: 0.85rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-weight: 500;
            letter-spacing: 0.5px;
        }

        .article-title {
            font-size: 2.5rem;
            font-weight: 700;
            line-height: 1.3;
            color: #1a1a1a;
            margin: 1.5rem 0;
        }

        .article-meta {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            flex-wrap: wrap;
            padding-top: 1rem;
            border-top: 1px solid #eee;
        }

        .article-meta .date {
            display: flex;
            align-items: center;
            color: #666;
            font-size: 0.95rem;
        }

        .article-meta .date i {
            margin-right: 0.5rem;
            color: #6c757d;
        }

        .article-content {
            background: white;
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            line-height: 1.8;
            color: #333;
        }

        .article-text {
            font-size: 1.125rem;
        }

        .article-text p {
            margin-bottom: 1.5rem;
        }

        .article-text h2,
        .article-text h3,
        .article-text h4 {
            margin-top: 2rem;
            margin-bottom: 1rem;
            color: #1a1a1a;
        }

        .article-text ul,
        .article-text ol {
            margin-left: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .article-text li {
            margin-bottom: 0.5rem;
        }

        .article-text a {
            color: #0d6efd;
            text-decoration: underline;
            transition: color 0.2s ease;
        }

        .article-text a:hover {
            color: #0a58ca;
        }

        /* Navigation */
        .article-navigation {
            padding: 2rem;
            background: white;
            border-radius: 16px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            margin-top: 3rem;
        }

        .share-buttons {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .share-buttons span {
            color: #666;
            font-weight: 500;
        }

        .share-buttons .btn {
            width: 42px;
            height: 42px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            padding: 0;
            transition: transform 0.2s ease;
        }

        .share-buttons .btn:hover {
            transform: scale(1.1);
        }

        /* Thumbnail Gallery */
        .thumbnail-gallery {
            display: flex;
            gap: 12px;
            margin-top: 20px;
            padding: 15px;
            overflow-x: auto;
            justify-content: center;
            background: #f8f9fa;
            border-radius: 12px;
            border: 1px solid #e9ecef;
        }

        .thumbnail-item {
            width: 90px;
            height: 70px;
            border-radius: 8px;
            overflow: hidden;
            cursor: pointer;
            opacity: 0.6;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            background: white;
            flex-shrink: 0;
        }

        .thumbnail-item:hover {
            opacity: 0.8;
            transform: translateY(-3px);
        }

        .thumbnail-item.active {
            opacity: 1;
            border-color: #0d6efd;
            transform: scale(1.08);
            box-shadow: 0 4px 12px rgba(13, 110, 253, 0.25);
        }

        .thumbnail-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .thumbnail-video {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: white;
            font-size: 1.5rem;
        }

        /* Empty State */
        .featured-media {
            height: 400px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #999;
            font-size: 1.1rem;
            background: #f8f9fa;
            border: 2px dashed #dee2e6;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .article-title {
                font-size: 2.2rem;
            }

            .carousel-inner {
                height: 550px;
            }
        }

        @media (max-width: 992px) {
            .container-spacing {
                padding: 0 1.5rem;
            }

            .article-title {
                font-size: 2rem;
            }

            .article-content {
                padding: 2rem;
            }

            .carousel-inner {
                height: 500px;
            }

            .carousel-control-prev,
            .carousel-control-next {
                width: 55px;
                height: 55px;
                margin: 0 15px;
            }

            .carousel-item {
                padding: 30px;
            }

            .carousel-item img,
            .carousel-item video {
                max-width: 85%;
                max-height: 85%;
            }
        }

        @media (max-width: 768px) {
            .article-container {
                padding: 1rem 0;
            }

            .article-title {
                font-size: 1.75rem;
            }

            .article-header {
                padding: 1.25rem;
            }

            .article-content {
                padding: 1.5rem;
            }

            .article-text {
                font-size: 1rem;
            }

            .carousel-inner {
                height: 450px;
            }

            .media-play-btn {
                width: 65px;
                height: 65px;
                font-size: 1.75rem;
            }

            .carousel-item {
                padding: 20px;
            }

            .article-navigation {
                padding: 1.5rem;
            }

            .article-navigation .d-flex {
                flex-direction: column;
                gap: 1.5rem;
            }

            .share-buttons {
                width: 100%;
                justify-content: center;
            }

            .thumbnail-gallery {
                justify-content: flex-start;
                padding: 12px;
            }

            .thumbnail-item {
                width: 80px;
                height: 60px;
            }

            .video-fullscreen-container {
                width: 100%;
                height: 100%;
            }

            .video-controls {
                padding: 15px;
            }

            .video-close-btn {
                width: 40px;
                height: 40px;
                font-size: 1.2rem;
            }
        }

        @media (max-width: 576px) {
            .article-title {
                font-size: 1.5rem;
            }

            .article-header {
                padding: 1rem;
            }

            .article-content {
                padding: 1.25rem;
            }

            .carousel-inner {
                height: 400px;
            }

            .carousel-control-prev,
            .carousel-control-next {
                width: 50px;
                height: 50px;
                margin: 0 10px;
            }

            .media-play-btn {
                width: 60px;
                height: 60px;
                font-size: 1.5rem;
            }

            .carousel-item {
                padding: 15px;
            }

            .article-meta {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.75rem;
            }

            .category-badge .badge {
                font-size: 0.8rem;
                padding: 0.4rem 0.8rem;
            }

            .thumbnail-item {
                width: 70px;
                height: 55px;
            }

            .video-control-buttons {
                gap: 10px;
            }

            .video-volume-control {
                display: none;
            }
        }

        @media (max-width: 400px) {
            .article-title {
                font-size: 1.35rem;
            }

            .article-text {
                font-size: 0.95rem;
            }

            .carousel-inner {
                height: 350px;
            }

            .carousel-indicators button {
                width: 10px;
                height: 10px;
            }

            .thumbnail-item {
                width: 65px;
                height: 50px;
            }
        }

        /* Dark mode support */
        @media (prefers-color-scheme: dark) {

            .article-header,
            .article-content,
            .article-navigation {
                background: #2d3748;
                color: #e2e8f0;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
            }

            .article-title {
                color: #f7fafc;
            }

            .article-text {
                color: #e2e8f0;
            }

            .article-meta .date {
                color: #a0aec0;
            }

            .article-text h2,
            .article-text h3,
            .article-text h4 {
                color: #f7fafc;
            }

            .media-carousel {
                background: #2d3748;
                border-color: #4a5568;
            }

            .carousel-item {
                background: #2d3748;
            }

            .carousel-control-prev,
            .carousel-control-next {
                background: rgba(45, 55, 72, 0.9);
                border-color: #4a5568;
                color: #e2e8f0;
            }

            .carousel-caption .media-counter {
                background: rgba(45, 55, 72, 0.9);
                color: #e2e8f0;
                border-color: #4a5568;
            }

            .media-play-btn {
                background: rgba(45, 55, 72, 0.95);
                color: #e2e8f0;
                border-color: #4a5568;
            }

            .thumbnail-gallery {
                background: #2d3748;
                border-color: #4a5568;
            }

            .thumbnail-item {
                background: #4a5568;
            }

            .thumbnail-item.active {
                border-color: #4299e1;
            }

            .featured-media {
                background: #2d3748;
                border-color: #4a5568;
                color: #cbd5e0;
            }
        }
    </style>

    <!-- Fullscreen Video Modal -->
    <div class="video-fullscreen-modal" id="videoFullscreenModal">
        <div class="video-fullscreen-container">
            <div class="video-fullscreen-header">
                <button class="video-close-btn" onclick="closeFullscreenVideo()">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>

            <div class="video-fullscreen-player">
                <video id="fullscreenVideo" controls>
                    Browser Anda tidak mendukung pemutar video.
                </video>
            </div>

            <div class="video-controls">
                <div class="video-progress" onclick="handleProgressClick(event)">
                    <div class="video-progress-bar" id="videoProgressBar"></div>
                </div>
                <div class="video-progress-time">
                    <span id="currentTime">0:00</span>
                    <span id="durationTime">0:00</span>
                </div>
                <div class="video-control-buttons">
                    <button class="video-control-btn" onclick="togglePlayPause()">
                        <i class="bi bi-play-fill" id="playPauseIcon"></i>
                    </button>
                    <button class="video-control-btn" onclick="skipBackward()">
                        <i class="bi bi-skip-backward-fill"></i>
                    </button>
                    <button class="video-control-btn" onclick="skipForward()">
                        <i class="bi bi-skip-forward-fill"></i>
                    </button>
                    <div class="video-volume-control">
                        <button class="video-control-btn" onclick="toggleMute()">
                            <i class="bi bi-volume-up-fill" id="volumeIcon"></i>
                        </button>
                        <div class="video-volume-slider" onclick="handleVolumeClick(event)">
                            <div class="video-volume-level" id="volumeLevel"></div>
                        </div>
                    </div>
                    <button class="video-control-btn video-fullscreen-btn" onclick="toggleNativeFullscreen()">
                        <i class="bi bi-arrows-fullscreen"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="article-container">
        <div class="container container-spacing">
            <div class="row justify-content-center">
                <div class="col-xxl-10 col-xl-10 col-lg-10 col-md-12">
                    <!-- Article Header -->
                    <header class="article-header">
                        <div class="category-badge mb-3">
                            <span class="badge bg-primary">{{ $konten->divisi->nama_divisi }}</span>
                        </div>
                        <h1 class="article-title">{{ $konten->judul }}</h1>
                        <div class="article-meta">
                            <div class="date">
                                <i class="bi bi-calendar-event"></i>
                                <span>{{ \Carbon\Carbon::parse($konten->tanggal_upload)->locale('id')->isoFormat('dddd, D MMMM Y') }}</span>
                            </div>
                        </div>
                    </header>

                    <!-- Featured Media Carousel -->
                    <div class="article-featured-image">
                        @php
                            $media = json_decode($konten->url_media, true) ?? [];
                        @endphp

                        @if (!empty($media))
                            <div class="media-carousel">
                                <div id="mediaCarousel" class="carousel">
                                    <!-- Indicators -->
                                    <div class="carousel-indicators" id="carouselIndicators">
                                        @foreach ($media as $index => $m)
                                            <button type="button" data-slide-to="{{ $index }}"
                                                class="{{ $index === 0 ? 'active' : '' }}"
                                                aria-label="Slide {{ $index + 1 }}"></button>
                                        @endforeach
                                    </div>

                                    <!-- Slides -->
                                    <div class="carousel-inner">
                                        @foreach ($media as $index => $m)
                                            @php
                                                $extension = strtolower(pathinfo($m, PATHINFO_EXTENSION));
                                                $isVideo = in_array($extension, ['mp4', 'mov', 'avi', 'webm', 'mkv']);
                                            @endphp
                                            <div class="carousel-item {{ $index === 0 ? 'active' : '' }}"
                                                data-index="{{ $index }}"
                                                data-type="{{ $isVideo ? 'video' : 'image' }}">

                                                @if ($isVideo)
                                                    <video id="video-{{ $index }}" src="{{ $m }}" muted
                                                        preload="metadata" playsinline
                                                        aria-label="Video konten {{ $konten->judul }}" class="video-media"
                                                        onclick="openFullscreenVideo('{{ $m }}', {{ $index }})">
                                                        Browser Anda tidak mendukung pemutar video.
                                                    </video>
                                                    <button class="media-play-btn"
                                                        onclick="openFullscreenVideo('{{ $m }}', {{ $index }})">
                                                        <i class="bi bi-play-fill"></i>
                                                    </button>
                                                @else
                                                    <img src="{{ $m }}"
                                                        alt="{{ $konten->judul }} - Gambar {{ $index + 1 }}"
                                                        loading="lazy"
                                                        onerror="this.src='https://via.placeholder.com/800x500?text=Gambar+Tidak+Tersedia'"
                                                        class="img-media" id="img-{{ $index }}"
                                                        onload="detectImageOrientation(this)">
                                                @endif

                                                <div class="carousel-caption">
                                                    <div class="media-counter">
                                                        {{ $index + 1 }} / {{ count($media) }}
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>

                                    <!-- Controls -->
                                    <button class="carousel-control-prev" onclick="prevSlide()">
                                        <i class="bi bi-chevron-left"></i>
                                        <span class="visually-hidden">Previous</span>
                                    </button>
                                    <button class="carousel-control-next" onclick="nextSlide()">
                                        <i class="bi bi-chevron-right"></i>
                                        <span class="visually-hidden">Next</span>
                                    </button>
                                </div>

                                <!-- Thumbnail Gallery -->
                                @if (count($media) > 1)
                                    <div class="thumbnail-gallery">
                                        @foreach ($media as $index => $m)
                                            @php
                                                $isVideo = in_array(strtolower(pathinfo($m, PATHINFO_EXTENSION)), [
                                                    'mp4',
                                                    'mov',
                                                    'avi',
                                                    'webm',
                                                    'mkv',
                                                ]);
                                            @endphp
                                            <div class="thumbnail-item {{ $index === 0 ? 'active' : '' }}"
                                                onclick="goToSlide({{ $index }})" data-index="{{ $index }}"
                                                title="Klik untuk melihat gambar {{ $index + 1 }}">
                                                @if ($isVideo)
                                                    <div class="thumbnail-video">
                                                        <i class="bi bi-play-fill"></i>
                                                    </div>
                                                @else
                                                    <img src="{{ $m }}" alt="Thumbnail {{ $index + 1 }}"
                                                        onerror="this.src='https://via.placeholder.com/80x60?text=Thumbnail'">
                                                @endif
                                            </div>
                                        @endforeach
                                    </div>
                                @endif
                            </div>
                        @else
                            <div class="featured-media">
                                <div class="text-center">
                                    <i class="bi bi-image display-4 mb-3 d-block"></i>
                                    <p>Tidak ada media yang tersedia</p>
                                </div>
                            </div>
                        @endif
                    </div>

                    <!-- Article Content -->
                    <article class="article-content">
                        <div class="article-text">
                            {!! '<p>' .
                                preg_replace(
                                    '/\n\s*\n/',
                                    '</p><p>',
                                    nl2br(
                                        strip_tags(
                                            $konten->deskripsi,
                                            '<b><i><u><mark><sub><sup><ul><ol><li><q><ruby><rt><rp><a><h1><h2><h3><h4><h5><h6><br><strong><em>',
                                        ),
                                    ),
                                ) .
                                '</p>' !!}
                        </div>
                    </article>

                    <!-- Navigation -->
                    <div class="article-navigation">
                        <div class="d-flex justify-content-between flex-md-row flex-column align-items-center">
                            <a href="/divisi/{{ $divisiKonten }}" class="btn btn-outline-primary px-4 py-2">
                                <i class="bi bi-arrow-left me-2"></i>Kembali ke Daftar Berita
                            </a>
                            <div class="share-buttons mt-2 mt-md-0">
                                <span class="share-label">Bagikan:</span>
                                <a href="https://wa.me/?text={{ urlencode(url()->current() . ' - ' . $konten->judul) }}"
                                    class="btn btn-success" target="_blank" rel="noopener noreferrer"
                                    aria-label="Bagikan ke WhatsApp">
                                    <i class="bi bi-whatsapp"></i>
                                </a>
                                <a href="https://www.facebook.com/sharer/sharer.php?u={{ urlencode(url()->current()) }}"
                                    class="btn btn-primary" target="_blank" rel="noopener noreferrer"
                                    aria-label="Bagikan ke Facebook">
                                    <i class="bi bi-facebook"></i>
                                </a>
                                <a href="https://twitter.com/intent/tweet?url={{ urlencode(url()->current()) }}&text={{ urlencode($konten->judul) }}"
                                    class="btn btn-info" target="_blank" rel="noopener noreferrer"
                                    aria-label="Bagikan ke Twitter">
                                    <i class="bi bi-twitter"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        class Carousel {
            constructor(element) {
                this.element = element;
                this.items = Array.from(element.querySelectorAll('.carousel-item'));
                this.indicators = Array.from(element.querySelectorAll('.carousel-indicators button'));
                this.thumbnails = Array.from(document.querySelectorAll('.thumbnail-item'));
                this.currentIndex = 0;
                this.totalItems = this.items.length;
                this.isAnimating = false;

                this.init();
            }

            init() {
                if (this.totalItems === 0) return;

                this.showSlide(this.currentIndex);

                // Add event listeners for keyboard navigation
                document.addEventListener('keydown', (e) => this.handleKeydown(e));

                // Add touch events for mobile
                this.addTouchEvents();
            }

            showSlide(index) {
                if (this.isAnimating || index < 0 || index >= this.totalItems) return;

                this.isAnimating = true;

                // Hide current slide
                this.items[this.currentIndex].classList.remove('active');
                this.indicators[this.currentIndex]?.classList.remove('active');
                this.thumbnails[this.currentIndex]?.classList.remove('active');

                // Pause video if current slide is video
                this.pauseVideo(this.currentIndex);

                // Update current index
                this.currentIndex = index;

                // Show new slide
                this.items[this.currentIndex].classList.add('active');
                this.indicators[this.currentIndex]?.classList.add('active');
                this.thumbnails[this.currentIndex]?.classList.add('active');

                // Update video controls
                this.updateVideoControls(this.currentIndex);

                // Detect and apply orientation for images
                this.detectImageOrientation(this.currentIndex);

                // Scroll thumbnail into view
                this.scrollThumbnailIntoView();

                // Reset animation flag after transition
                setTimeout(() => {
                    this.isAnimating = false;
                }, 600);
            }

            next() {
                const nextIndex = (this.currentIndex + 1) % this.totalItems;
                this.showSlide(nextIndex);
            }

            prev() {
                const prevIndex = (this.currentIndex - 1 + this.totalItems) % this.totalItems;
                this.showSlide(prevIndex);
            }

            goTo(index) {
                this.showSlide(index);
            }

            pauseVideo(index) {
                const video = document.getElementById(`video-${index}`);
                if (video) {
                    video.pause();
                }
            }

            updateVideoControls(index) {
                const item = this.items[index];
                if (!item) return;

                const playBtn = item.querySelector('.media-play-btn');
                const video = item.querySelector('video');

                if (playBtn && video) {
                    if (video.paused) {
                        playBtn.classList.remove('hidden');
                        playBtn.innerHTML = '<i class="bi bi-play-fill"></i>';
                    } else {
                        playBtn.classList.add('hidden');
                    }
                }
            }

            detectImageOrientation(index) {
                const img = document.getElementById(`img-${index}`);
                if (!img) return;

                // Remove previous orientation classes
                img.removeAttribute('data-orientation');

                // Check if image is loaded
                if (img.complete && img.naturalWidth && img.naturalHeight) {
                    const isVertical = img.naturalHeight > img.naturalWidth;
                    img.setAttribute('data-orientation', isVertical ? 'vertical' : 'horizontal');
                }
            }

            handleKeydown(e) {
                if (e.key === 'ArrowLeft') {
                    e.preventDefault();
                    this.prev();
                } else if (e.key === 'ArrowRight') {
                    e.preventDefault();
                    this.next();
                } else if (e.key === ' ') {
                    e.preventDefault();
                    const activeItem = this.items[this.currentIndex];
                    if (activeItem && activeItem.dataset.type === 'video') {
                        const videoUrl = activeItem.querySelector('video')?.src;
                        if (videoUrl) {
                            openFullscreenVideo(videoUrl, this.currentIndex);
                        }
                    }
                } else if (e.key === 'Escape') {
                    closeFullscreenVideo();
                }
            }

            addTouchEvents() {
                let touchStartX = 0;
                let touchEndX = 0;
                let isSwiping = false;

                this.element.addEventListener('touchstart', (e) => {
                    touchStartX = e.changedTouches[0].screenX;
                    isSwiping = true;
                }, {
                    passive: true
                });

                this.element.addEventListener('touchmove', (e) => {
                    if (!isSwiping) return;
                    touchEndX = e.changedTouches[0].screenX;
                }, {
                    passive: true
                });

                this.element.addEventListener('touchend', (e) => {
                    if (!isSwiping) return;
                    touchEndX = e.changedTouches[0].screenX;
                    this.handleSwipe(touchStartX, touchEndX);
                    isSwiping = false;
                }, {
                    passive: true
                });
            }

            handleSwipe(startX, endX) {
                const swipeThreshold = 30;
                const swipeDistance = endX - startX;

                if (Math.abs(swipeDistance) > swipeThreshold) {
                    if (swipeDistance > 0) {
                        this.prev();
                    } else {
                        this.next();
                    }
                }
            }

            scrollThumbnailIntoView() {
                const activeThumbnail = this.thumbnails[this.currentIndex];
                if (activeThumbnail) {
                    activeThumbnail.scrollIntoView({
                        behavior: 'smooth',
                        block: 'nearest',
                        inline: 'center'
                    });
                }
            }
        }

        // Video Player State
        let fullscreenVideo = null;
        let isPlaying = false;
        let isMuted = false;
        let currentVolume = 1.0;
        let carousel = null;

        document.addEventListener('DOMContentLoaded', function() {
            const carouselElement = document.getElementById('mediaCarousel');
            if (carouselElement) {
                carousel = new Carousel(carouselElement);
            }

            fullscreenVideo = document.getElementById('fullscreenVideo');

            // Initialize video event listeners
            if (fullscreenVideo) {
                fullscreenVideo.addEventListener('timeupdate', updateProgress);
                fullscreenVideo.addEventListener('loadedmetadata', updateDuration);
                fullscreenVideo.addEventListener('play', () => {
                    isPlaying = true;
                    updatePlayPauseIcon();
                });
                fullscreenVideo.addEventListener('pause', () => {
                    isPlaying = false;
                    updatePlayPauseIcon();
                });
                fullscreenVideo.addEventListener('volumechange', updateVolume);
                fullscreenVideo.addEventListener('ended', () => {
                    isPlaying = false;
                    updatePlayPauseIcon();
                });

                // Initialize volume
                fullscreenVideo.volume = currentVolume;
                updateVolume();
            }

            // Detect orientation for all images after they load
            document.querySelectorAll('.carousel-item img').forEach(img => {
                if (img.complete) {
                    detectImageOrientation(img);
                } else {
                    img.addEventListener('load', function() {
                        detectImageOrientation(this);
                    });
                }
            });

            // Close fullscreen video when clicking outside
            document.getElementById('videoFullscreenModal').addEventListener('click', function(e) {
                if (e.target === this) {
                    closeFullscreenVideo();
                }
            });

            // Keyboard controls for fullscreen video
            document.addEventListener('keydown', function(e) {
                if (!document.getElementById('videoFullscreenModal').classList.contains('active')) return;

                switch (e.key) {
                    case ' ':
                        e.preventDefault();
                        togglePlayPause();
                        break;
                    case 'Escape':
                        closeFullscreenVideo();
                        break;
                    case 'ArrowLeft':
                        e.preventDefault();
                        skipBackward();
                        break;
                    case 'ArrowRight':
                        e.preventDefault();
                        skipForward();
                        break;
                    case 'm':
                    case 'M':
                        e.preventDefault();
                        toggleMute();
                        break;
                    case 'f':
                    case 'F':
                        e.preventDefault();
                        toggleNativeFullscreen();
                        break;
                }
            });
        });

        // Global function to detect image orientation
        function detectImageOrientation(img) {
            if (!img.complete || !img.naturalWidth || !img.naturalHeight) return;

            const isVertical = img.naturalHeight > img.naturalWidth;
            img.setAttribute('data-orientation', isVertical ? 'vertical' : 'horizontal');
        }

        // Global functions for button clicks
        function nextSlide() {
            if (carousel) carousel.next();
        }

        function prevSlide() {
            if (carousel) carousel.prev();
        }

        function goToSlide(index) {
            if (carousel) carousel.goTo(index);
        }

        function openFullscreenVideo(videoUrl, index) {
            if (!fullscreenVideo) return;

            // Set video source
            fullscreenVideo.src = videoUrl;

            // Show modal
            const modal = document.getElementById('videoFullscreenModal');
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';

            // Try to play the video
            fullscreenVideo.play().then(() => {
                isPlaying = true;
                updatePlayPauseIcon();
            }).catch(e => {
                console.log('Video autoplay failed:', e);
            });
        }

        function closeFullscreenVideo() {
            if (!fullscreenVideo) return;

            // Pause video
            fullscreenVideo.pause();
            isPlaying = false;

            // Hide modal
            const modal = document.getElementById('videoFullscreenModal');
            modal.classList.remove('active');
            document.body.style.overflow = '';

            // Reset video source to prevent memory leak
            setTimeout(() => {
                fullscreenVideo.src = '';
            }, 100);
        }

        function togglePlayPause() {
            if (!fullscreenVideo) return;

            if (fullscreenVideo.paused) {
                fullscreenVideo.play();
            } else {
                fullscreenVideo.pause();
            }
        }

        function updatePlayPauseIcon() {
            const icon = document.getElementById('playPauseIcon');
            if (icon) {
                icon.className = isPlaying ? 'bi bi-pause-fill' : 'bi bi-play-fill';
            }
        }

        function skipBackward() {
            if (!fullscreenVideo) return;
            fullscreenVideo.currentTime = Math.max(0, fullscreenVideo.currentTime - 10);
        }

        function skipForward() {
            if (!fullscreenVideo) return;
            fullscreenVideo.currentTime = Math.min(fullscreenVideo.duration, fullscreenVideo.currentTime + 10);
        }

        function toggleMute() {
            if (!fullscreenVideo) return;

            isMuted = !isMuted;
            fullscreenVideo.muted = isMuted;
            updateVolumeIcon();
        }

        function updateVolumeIcon() {
            const icon = document.getElementById('volumeIcon');
            if (!icon) return;

            if (isMuted || fullscreenVideo.volume === 0) {
                icon.className = 'bi bi-volume-mute-fill';
            } else if (fullscreenVideo.volume < 0.5) {
                icon.className = 'bi bi-volume-down-fill';
            } else {
                icon.className = 'bi bi-volume-up-fill';
            }
        }

        function handleVolumeClick(e) {
            if (!fullscreenVideo) return;

            const slider = e.currentTarget;
            const rect = slider.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const width = rect.width;

            const volume = Math.max(0, Math.min(1, x / width));
            currentVolume = volume;
            fullscreenVideo.volume = volume;
            fullscreenVideo.muted = volume === 0;
            isMuted = volume === 0;

            updateVolume();
            updateVolumeIcon();
        }

        function updateVolume() {
            if (!fullscreenVideo) return;

            const volumeLevel = document.getElementById('volumeLevel');
            if (volumeLevel) {
                const volume = isMuted ? 0 : fullscreenVideo.volume;
                volumeLevel.style.width = (volume * 100) + '%';
            }
        }

        function handleProgressClick(e) {
            if (!fullscreenVideo || !fullscreenVideo.duration) return;

            const progress = e.currentTarget;
            const rect = progress.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const width = rect.width;

            const time = (x / width) * fullscreenVideo.duration;
            fullscreenVideo.currentTime = time;
        }

        function updateProgress() {
            if (!fullscreenVideo || !fullscreenVideo.duration) return;

            const progressBar = document.getElementById('videoProgressBar');
            const currentTimeElement = document.getElementById('currentTime');

            if (progressBar) {
                const progress = (fullscreenVideo.currentTime / fullscreenVideo.duration) * 100;
                progressBar.style.width = progress + '%';
            }

            if (currentTimeElement) {
                currentTimeElement.textContent = formatTime(fullscreenVideo.currentTime);
            }
        }

        function updateDuration() {
            if (!fullscreenVideo || !fullscreenVideo.duration) return;

            const durationElement = document.getElementById('durationTime');
            if (durationElement) {
                durationElement.textContent = formatTime(fullscreenVideo.duration);
            }
        }

        function formatTime(seconds) {
            const mins = Math.floor(seconds / 60);
            const secs = Math.floor(seconds % 60);
            return `${mins}:${secs.toString().padStart(2, '0')}`;
        }

        function toggleNativeFullscreen() {
            if (!fullscreenVideo) return;

            const container = document.querySelector('.video-fullscreen-container');

            if (!document.fullscreenElement) {
                if (container.requestFullscreen) {
                    container.requestFullscreen();
                } else if (container.webkitRequestFullscreen) {
                    container.webkitRequestFullscreen();
                } else if (container.msRequestFullscreen) {
                    container.msRequestFullscreen();
                }
            } else {
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                } else if (document.webkitExitFullscreen) {
                    document.webkitExitFullscreen();
                } else if (document.msExitFullscreen) {
                    document.msExitFullscreen();
                }
            }
        }

        // Listen for fullscreen change
        document.addEventListener('fullscreenchange', function() {
            const fullscreenBtn = document.querySelector('.video-fullscreen-btn i');
            if (fullscreenBtn) {
                fullscreenBtn.className = document.fullscreenElement ?
                    'bi bi-fullscreen-exit' : 'bi bi-arrows-fullscreen';
            }
        });

        // Cleanup on page unload
        window.addEventListener('beforeunload', function() {
            if (carousel) {
                carousel.items.forEach((item, index) => {
                    if (item.dataset.type === 'video') {
                        const video = document.getElementById(`video-${index}`);
                        if (video) video.pause();
                    }
                });
            }

            closeFullscreenVideo();
        });
    </script>
@endsection
