@extends('admin.layouts.main')

@section('container')
    @if(Request::is('manage/user'))
        <script>
            document.addEventListener("DOMContentLoaded", function(){
                document.querySelectorAll('#sidebarMenu a').forEach(button => {
                    button.addEventListener('click', function() {
                        document.querySelectorAll('#sidebarMenu a').forEach(btn => {
                            btn.classList.remove('bg-blue-100', 'text-blue-800');
                            btn.classList.add('text-gray-600');
                            btn.querySelector('svg').classList.remove('text-blue-800');
                            btn.querySelector('svg').classList.add('text-gray-600');
                        });
                        this.querySelector('svg').classList.remove('text-gray-600');
                        this.querySelector('svg').classList.add('text-blue-800');
                    });
                });
                document.getElementById('btn-user-section').classList.remove('text-gray-600');
                document.getElementById('btn-user-section').classList.add('bg-blue-100', 'text-blue-800');

                @if (Auth::user()->role == 'superadmin')
                    document.getElementById('btn-calendar-section').addEventListener('click', function() {
                        window.location.href = "/manage/event"
                    });

                    document.getElementById('btn-user-section').addEventListener('click', function() {
                        window.location.href = "/manage/user"
                    });

                    document.getElementById('btn-sponsor-section').addEventListener('click', function() {
                        window.location.href = "/sponsor"
                    });
                @endif

                document.getElementById('btn-gallery-section').addEventListener('click', function() {
                    window.location.href = "/gallery";
                });
            });
        </script>
    @endif

    <!-- Accounts Section -->
    <div id="accountSection" class="p-8 mt-5 flex-1">
        <div class="flex flex-row justify-between align-text-top">
            <h2 class="text-2xl text-gray-700 mb-8 font-['Nunito']">Manage Account</h2>
            <div id="btn-addAcc" class="flex flex-row lg:p-3 max-lg:p-1.5 lg:px-5 max-lg:px-4 max-lg:text-sm text-center text-white bg-green-600 cursor-pointer w-max h-max hover:bg-green-700 rounded-xl lg:fixed lg:bottom-7 right-7">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="mt-auto lg:w-6 max-lg:w-4 mb-auto mr-1 bi bi-plus" viewBox="0 0 16 16">
                    <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
                </svg>
                Tambah baru
            </div>
            <script>
                document.getElementById('btn-addAcc').addEventListener('click', function() {
                    window.open('{{route('subadmin.create')}}', '_self');
                });
            </script>
        </div>
        {{-- <div class="p-10 text-center bg-white rounded-lg shadow-md">
            <div id="accountContent" class="bootstrap-table">
                <table class="border border-collapse border-gray-300">
                    <thead class="bg-gray-100">
                        <tr class="text-center">
                            <th class="px-4 py-2 text-center border border-gray-300">No</th>
                            <th class="px-4 py-2 text-center border border-gray-300">Divisi</th>
                            <th class="px-4 py-2 text-center border border-gray-300">Nama</th>
                            <th class="px-4 py-2 text-center border border-gray-300">Username</th>
                            <th class="px-4 py-2 text-center border border-gray-300">Email</th>
                            <th class="px-4 py-2 text-center border border-gray-300">Role</th>
                            <th class="px-4 py-2 text-center border border-gray-300">Alamat</th>
                            <th class="px-4 py-2 text-center border border-gray-300">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($dataAkun as $kontenAkun)
                            <tr>
                                <td class="px-4 py-2 border border-gray-300">{{ ($dataAkun->currentPage() - 1) * $dataAkun->perPage() + $loop->iteration }}</td>
                                <td class="px-4 py-2 border border-gray-300">{{$kontenAkun->divisi->nama_divisi}}</td>
                                <td class="px-4 py-2 border border-gray-300">{{$kontenAkun->name}}</td>
                                <td class="px-4 py-2 border border-gray-300">{{$kontenAkun->username}}</td>
                                <td class="px-4 py-2 border border-gray-300">{{$kontenAkun->email}}</td>
                                <td class="px-4 py-2 border border-gray-300">{{$kontenAkun->role}}</td>
                                <td class="px-4 py-2 border border-gray-300">{{$kontenAkun->alamat}}</td>
                                <td class="px-4 py-2 text-center border border-gray-300">
                                    <button class="p-2 mb-2 text-white bg-orange-500 rounded-lg btn-updateAkun" data-idAkun="{{$kontenAkun['id']}}">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                            <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                            <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                                        </svg>
                                    </button>
                                    <button class="p-2 text-white bg-red-600 rounded-lg btn-deleteAkun" data-idAkun="{{$kontenAkun['id']}}" data-namaAkun="{{$kontenAkun['name']}}">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16">
                                            <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5"/>
                                        </svg>
                                    </button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                @include('components.pagination-account', ['data' => $dataAkun])
            </div>
        </div> --}}

        <div class="max-lg:p-6 lg:p-10 bg-white rounded-lg shadow-md">
            <!-- Wrapper untuk Scroll Horizontal -->
            <div id="accountContent">
                <div class="overflow-x-auto">
                    <table class="w-full border border-gray-300">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="px-4 py-2 border border-gray-300">No</th>
                                <th class="px-4 py-2 border border-gray-300">Divisi</th>
                                <th class="px-4 py-2 border border-gray-300">Nama</th>
                                <th class="px-4 py-2 border border-gray-300">Username</th>
                                <th class="px-4 py-2 border border-gray-300">Email</th>
                                <th class="px-4 py-2 border border-gray-300">Role</th>
                                <th class="px-4 py-2 border border-gray-300">Alamat</th>
                                <th class="px-4 py-2 border border-gray-300">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($dataAkun as $kontenAkun)
                                <tr>
                                    <td class="px-4 py-2 text-sm border border-gray-300">
                                        {{ ($dataAkun->currentPage() - 1) * $dataAkun->perPage() + $loop->iteration }}
                                    </td>
                                    <td class="px-4 py-2 border border-gray-300">{{$kontenAkun->divisi->nama_divisi}}</td>
                                    <td class="px-4 py-2 border border-gray-300">{{$kontenAkun->name}}</td>
                                    <td class="px-4 py-2 border border-gray-300">{{$kontenAkun->username}}</td>
                                    <td class="px-4 py-2 border border-gray-300">{{$kontenAkun->email}}</td>
                                    <td class="px-4 py-2 border border-gray-300">{{$kontenAkun->role}}</td>
                                    <td class="px-4 py-2 border border-gray-300">{{ \Illuminate\Support\Str::limit($kontenAkun->alamat, 27, '...') }}</td>
                                    <td class="px-4 py-2 text-center border border-gray-300">
                                        <button class="p-2 mb-2 text-white bg-orange-500 rounded-lg btn-updateAkun" data-idAkun="{{$kontenAkun['id']}}">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                                <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                                            </svg>
                                        </button>
                                        <button class="p-2 text-white bg-red-600 rounded-lg btn-deleteAkun" data-idAkun="{{$kontenAkun['id']}}" data-namaAkun="{{$kontenAkun['name']}}">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16">
                                                <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5"/>
                                            </svg>
                                        </button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                @include('components.pagination-account', ['data' => $dataAkun])
            </div>
        </div>
    </div>
@endsection