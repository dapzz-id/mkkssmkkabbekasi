<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MKKS SMK BEKASI</title>
    <link rel="stylesheet" href="{{asset('dist/css/main.css')}}">
    <link rel="icon" href="{{ asset('img/ic_MKKS.png') }}" type="image/png">
    <link rel="icon" href="{{asset('img/ic_MKKS.ico')}}" type="image/x-icon">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <style>
            #content:hover, #content:hover svg {
                color: #2563eb;
            }
            *{
                outline: none;
                caret-color: transparent;
            }
        </style>
</head>
<body>
    <div class="flex flex-wrap items-center justify-between w-full py-4 mb-3 text-center border-b sticky top-0">
        <img src="{{asset('img/ic_MKKS.png')}}" class="w-auto h-12 ml-5" alt="">
        <h1 class="text-2xl font-bold">Edit Tanggal Acara</h1>
        <div></div>
    </div>
    <div class="p-6 sm:p-12 lg:p-24 flex justify-center items-center">
        <main class="w-full max-w-lg bg-white shadow-md rounded-md p-6">

            @if(session('success'))
                <div class="px-4 py-3 mb-4 text-green-700 bg-green-100 border border-green-400 rounded">
                    {{ session('success') }}
                </div>
            @endif

            <form action="{{ route('calendar.update', $calendar->id) }}" id="form1" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-gray-700">Nama Acara</label>
                    <input type="text" value="{{$calendar['event_name']}}" class="mt-1 block w-full caret-black px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200 @error('name') border-red-500 @enderror" id="name" name="name" required>
                    @error('name')
                        <p class="mt-1 text-xs text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="date" class="block text-sm font-medium text-gray-700">Tanggal Acara</label>
                    <input type="date" value="{{$calendar['event_date']}}" class="mt-1 block w-full px-3 py-2 caret-black border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200 @error('date') border-red-500 @enderror" name="date" id="date" required>
                    @error('date')
                        <p class="mt-1 text-xs text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <button type="button" id="btn-confirm" class="px-4 py-2 w-full font-semibold text-white bg-blue-500 rounded-md shadow hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300">Perbarui Jadwal</button>
                <a id="btn-back" class="px-4 py-2 text-center mt-2 w-full block font-semibold text-white bg-gray-500 rounded-md shadow cursor-pointer hover:bg-gray-600 focus:outline-none focus:ring focus:ring-gray-300">Kembali</a>
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        document.getElementById('btn-back').addEventListener('click', function() {
                            window.location.href = "/manage/event";
                        });
                        document.getElementById('btn-confirm').addEventListener('click', function(){
                            Swal.fire({
                                title: "Apakah Anda yakin ingin mengedit data ini?",
                                text: "Data ini akan diupdate dan disimpan...",
                                icon: "question",
                                showCancelButton: true,
                                confirmButtonColor: "#3085d6",
                                cancelButtonColor: "#d33",
                                confirmButtonText: "Yes"
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    document.getElementById('form1').submit();
                                }
                            });
                        })
                    });
                </script>
            </form>
        </main>
    </div>
</body>
</html>
