<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MKKS SMK BEKASI - Tambah Galeri</title>
    <link rel="stylesheet" href="{{asset('dist/css/main.css')}}">
    <link rel="icon" href="{{ asset('img/ic_MKKS.png') }}" type="image/png">
    <link rel="icon" href="{{asset('img/ic_MKKS.ico')}}" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        * {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            caret-color: transparent;
        }
        
        body {
            background-color: #f8fafc;
            color: #334155;
        }
        
        /* Header Styling */
        .site-header {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            padding: 1rem 2rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            position: sticky;
            top: 0;
            z-index: 50;
        }
        
        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .logo-container {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .logo {
            height: 2.5rem;
            width: auto;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));
        }
        
        .site-title {
            color: white;
            font-size: 1.5rem;
            font-weight: 600;
            letter-spacing: -0.025em;
        }
        
        /* Form Container */
        .form-container {
            max-width: 32rem;
            margin: 3rem auto;
            padding: 0 1rem;
        }
        
        .form-card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }
        
        .form-header {
            padding: 1.5rem 2rem;
            border-bottom: 1px solid #e2e8f0;
            background-color: #f8fafc;
        }
        
        .form-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #1e293b;
            margin: 0;
        }
        
        .form-body {
            padding: 2rem;
        }
        
        /* Form Elements */
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            color: #475569;
            margin-bottom: 0.5rem;
        }
        
        .form-input, .form-select, .form-textarea {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid #cbd5e1;
            border-radius: 0.75rem;
            font-size: 0.875rem;
            transition: all 0.2s ease;
            background-color: white;
            caret-color: #2563eb;
        }
        
        .form-input:focus, .form-select:focus, .form-textarea:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }
        
        .form-input:hover, .form-select:hover, .form-textarea:hover {
            border-color: #94a3b8;
        }
        
        /* Media Upload */
        .media-upload-container {
            border: 2px dashed #cbd5e1;
            border-radius: 0.75rem;
            padding: 1.5rem;
            transition: all 0.2s ease;
        }
        
        .media-upload-container:hover {
            border-color: #94a3b8;
            background-color: #f8fafc;
        }
        
        .media-preview {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
            gap: 0.75rem;
            margin-top: 1rem;
        }
        
        .preview-item {
            position: relative;
            border-radius: 0.5rem;
            overflow: hidden;
            aspect-ratio: 1;
            background-color: #f1f5f9;
        }
        
        .preview-media {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .remove-preview {
            position: absolute;
            top: 0.25rem;
            right: 0.25rem;
            background-color: rgba(239, 68, 68, 0.9);
            color: white;
            border: none;
            border-radius: 50%;
            width: 1.5rem;
            height: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .remove-preview:hover {
            background-color: #dc2626;
            transform: scale(1.1);
        }
        
        /* Media Field */
        .media-field {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
        }
        
        .remove-field {
            background-color: rgba(239, 68, 68, 0.9);
            color: white;
            border: none;
            border-radius: 50%;
            width: 1.5rem;
            height: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            cursor: pointer;
            transition: all 0.2s ease;
            flex-shrink: 0;
        }
        
        .remove-field:hover {
            background-color: #dc2626;
            transform: scale(1.1);
        }
        
        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 500;
            font-size: 0.875rem;
            cursor: pointer;
            transition: all 0.2s ease;
            border: none;
            text-decoration: none;
            width: 100%;
        }
        
        .btn-primary {
            background-color: #2563eb;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #1d4ed8;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.2);
        }
        
        .btn-secondary {
            background-color: #64748b;
            color: white;
            margin-top: 0.75rem;
        }
        
        .btn-secondary:hover {
            background-color: #475569;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(100, 116, 139, 0.2);
        }
        
        .btn-add {
            background-color: #10b981;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            font-size: 0.875rem;
            margin-top: 0.5rem;
        }
        
        .btn-add:hover {
            background-color: #059669;
        }
        
        /* Error States */
        .error-input {
            border-color: #ef4444 !important;
        }
        
        .error-message {
            color: #ef4444;
            font-size: 0.75rem;
            margin-top: 0.25rem;
        }
        
        .success-message {
            background-color: #dcfce7;
            border: 1px solid #86efac;
            color: #166534;
            padding: 0.75rem 1rem;
            border-radius: 0.75rem;
            margin-bottom: 1.5rem;
            font-size: 0.875rem;
        }
        
        /* Note */
        .form-note {
            font-size: 0.75rem;
            color: #ef4444;
            margin-top: -1rem;
            margin-bottom: 1.5rem;
        }
        
        /* Responsive */
        @media (max-width: 640px) {
            .form-container {
                margin: 1.5rem auto;
            }
            
            .form-body {
                padding: 1.5rem;
            }
            
            .site-header {
                padding: 1rem;
            }
            
            .header-content {
                flex-direction: column;
                gap: 0.75rem;
            }
        }
    </style>
</head>
<body>    
    <div class="form-container">
        <main class="form-card">
            @if(session('success'))
                <div class="success-message">
                    {{ session('success') }}
                </div>
            @endif
    
            <div class="form-header">
                <h2 class="form-title text-center">Tambah Galeri</h2>
            </div>
            
            <form action="{{ route('galeri.store') }}" id="form1" method="POST" enctype="multipart/form-data" class="form-body">
                @csrf
                
                <div class="form-group">
                    <label for="judul" class="form-label">Judul</label>
                    <input type="text" class="form-input @error('judul') error-input @enderror" id="judul" name="judul" required placeholder="Masukkan judul galeri">
                    @error('judul')
                        <p class="error-message">{{ $message }}</p>
                    @enderror
                </div>
    
                <div class="form-group">
                    <label for="divisi" class="form-label">Divisi</label>
                    @php
                        if(Auth::user()->role == 'superadmin'){
                            $divisi = DB::table('divisi')
                                    ->select('id', 'nama_divisi')
                                    ->get();
                        }else if(Auth::user()->role == 'admin'){
                            $divisi = DB::table('divisi')
                            ->select('divisi.id', 'divisi.nama_divisi')
                            ->join('user', 'user.id_divisi', '=', 'divisi.id')
                            ->where('user.id', Auth::user()->id)
                            ->get();
                        }
                    @endphp
                    <select class="form-select @error('id_divisi') error-input @enderror" id="divisi" name="id_divisi" required readonly>
                        <option value="" selected>Pilih Divisi</option>
                        @foreach($divisi as $item)
                            <option value="{{ $item->id }}" {{ Auth::user()->id_divisi == $item->id ? 'selected' : '' }}>
                                {{ $item->nama_divisi }}
                            </option>
                        @endforeach
                    </select>
                    @error('id_divisi')
                        @if ($message == 'validation.required')
                            <p class="error-message">Divisi diperlukan!</p>
                        @endif
                    @enderror
                </div>
    
                <div class="form-group">
                    <label class="form-label">Unggah Media</label>
                    <div class="media-upload-container">
                        <div id="mediaFields"></div>
                        <button type="button" id="add-media" class="btn-add">+ Tambah Media</button>
                        <div id="previewContainer" class="media-preview"></div>
                    </div>
                    @error('media.*')
                        <p class="error-message">{{ $message }}</p>
                    @enderror
                </div>
    
                <div class="form-group">
                    <label for="deskripsi" class="form-label">Deskripsi</label>
                    <textarea class="form-textarea @error('deskripsi') error-input @enderror" id="deskripsi" name="deskripsi" rows="4" required placeholder="Masukkan deskripsi galeri"></textarea>
                    @error('deskripsi')
                        <p class="error-message">{{ $message }}</p>
                    @enderror
                </div>
                
                <p class="form-note">*Kolom deskripsi mendukung format tag html seperti bold, italic, underline, dll</p>
    
                <button type="button" id="btn-confirm" class="btn btn-primary">Tambah Galeri</button>
                <a id="btn-back" class="btn btn-secondary">Kembali</a>
            </form>
        </main>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const mediaFields = document.getElementById('mediaFields');
        const previewContainer = document.getElementById('previewContainer');
        const addMediaBtn = document.getElementById('add-media');
        let mediaCount = 0;

        function addMediaField(required = false) {
            const count = mediaCount;
            const fieldId = `media-${count}`;
            const divId = `field-${count}`;
            const field = document.createElement('div');
            field.classList.add('media-field');
            field.id = divId;
            field.innerHTML = `
                <input type="file" id="${fieldId}" class="form-input" name="media[]" accept="image/*,video/*" ${required ? 'required' : ''} onchange="previewMedia(this, '${fieldId}')">
                ${!required ? `<button type="button" class="remove-field" onclick="removeMediaField('${divId}', '${fieldId}')">×</button>` : ''}
            `;
            mediaFields.appendChild(field);
            mediaCount++;
        }

        // Add initial field
        addMediaField(true);

        addMediaBtn.addEventListener('click', () => addMediaField());

        // Preview media function
        window.previewMedia = function(input, fieldId) {
            const file = input.files[0];
            
            if (file) {
                const reader = new FileReader();
                reader.onloadend = function () {
                    const previewId = `preview-${fieldId}`;
                    
                    // Remove existing preview for this field if exists
                    const existingPreview = document.getElementById(previewId);
                    if (existingPreview) {
                        existingPreview.remove();
                    }
                    
                    let elem;
                    if (file.type.startsWith('image/')) {
                        elem = document.createElement('img');
                        elem.src = reader.result;
                        elem.classList.add('preview-media');
                    } else if (file.type.startsWith('video/')) {
                        elem = document.createElement('video');
                        elem.src = reader.result;
                        elem.classList.add('preview-media');
                        elem.controls = true;
                        elem.muted = true;
                    }
                    
                    if (elem) {
                        const previewItem = document.createElement('div');
                        previewItem.classList.add('preview-item');
                        previewItem.id = previewId;
                        
                        const removeBtn = document.createElement('button');
                        removeBtn.type = 'button';
                        removeBtn.classList.add('remove-preview');
                        removeBtn.innerHTML = '×';
                        removeBtn.onclick = function() {
                            previewItem.remove();
                            const fieldDiv = input.parentNode;
                            fieldDiv.remove();
                            if (mediaFields.children.length === 0) {
                                addMediaField(true);
                            }
                        };
                        
                        previewItem.appendChild(elem);
                        previewItem.appendChild(removeBtn);
                        previewContainer.appendChild(previewItem);
                    }
                };
                reader.readAsDataURL(file);
            }
        };

        // Remove media field function
        window.removeMediaField = function(divId, fieldId) {
            const fieldDiv = document.getElementById(divId);
            const previewId = `preview-${fieldId}`;
            const existingPreview = document.getElementById(previewId);
            if (existingPreview) {
                existingPreview.remove();
            }
            fieldDiv.remove();
            if (mediaFields.children.length === 0) {
                addMediaField(true);
            }
        };

        document.getElementById('btn-back').addEventListener('click', function() {
            window.location.href = "/gallery";
        });

        document.getElementById('btn-confirm').addEventListener('click', function() {
            Swal.fire({
                title: "Konfirmasi",
                text: "Apakah Anda yakin ingin menambahkan galeri ini?",
                icon: "question",
                showCancelButton: true,
                confirmButtonColor: "#2563eb",
                cancelButtonColor: "#64748b",
                confirmButtonText: "Ya, Tambahkan",
                cancelButtonText: "Batal",
                background: '#fff',
                color: '#334155'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('form1').submit();
                }
            });
        });
    });
    </script>
</body>
</html>