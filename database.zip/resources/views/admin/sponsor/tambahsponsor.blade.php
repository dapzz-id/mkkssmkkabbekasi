<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MKKS SMK BEKASI</title>
    <link rel="stylesheet" href="{{asset('dist/css/main.css')}}">
    <link rel="icon" href="{{ asset('img/ic_MKKS.png') }}" type="image/png">
    <link rel="icon" href="{{asset('img/ic_MKKS.ico')}}" type="image/x-icon">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <style>
            #content:hover, #content:hover svg {
                color: #2563eb;
            }
            *{
                outline: none;
                caret-color: transparent;
            }
        </style>
</head>
<body>
    <div class="w-full flex justify-between flex-wrap items-center py-4 text-center mb-3 border-b sticky top-0">
        <img src="{{asset('img/ic_MKKS.png')}}" class="w-auto h-12 ml-5" alt="">
        <h1 class="text-2xl font-bold">Edit Sponsor</h1>
        <div></div>
    </div>
    <div class="p-6 sm:p-12 lg:p-24 flex justify-center items-center">
        <main class="w-full max-w-lg bg-white shadow-md rounded-md p-6">
        
            @if(session('success'))
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    {{ session('success') }}
                </div>
            @endif
        
            <form action="{{ route('sponsor.store') }}" id="form1" method="POST" enctype="multipart/form-data">
                @csrf

                <div class="mb-4">
                    <label for="nama" class="block text-sm font-medium text-gray-700">Nama Sponsor</label>
                    <input type="text" class="mt-1 block w-full px-3 py-2 border caret-black border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200 @error('nama') border-red-500 @enderror" id="nama" name="nama" required>
                    @error('nama')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>
        
                <div class="mb-4">
                    <label for="url_image" class="block text-sm font-medium text-gray-700">Unggah Foto Sponsor</label>
                    <input type="file" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200 @error('url_image') border-red-500 @enderror" id="url_image" name="url_image" accept="image/*" onchange="previewImage()" required>
                    <img id="imagePreview" class="mt-2 max-w-[100px] max-h-[100px]">
                    @error('url_image')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>
                
                <button type="button" id="btn-submitAdd" class="px-4 py-2 w-full bg-blue-500 text-white font-semibold rounded-md shadow hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300">Tambah Sponsor</button>
                <a id="btn-back" class="mt-2 px-4 py-2 w-full block text-center cursor-pointer bg-gray-500 text-white font-semibold rounded-md shadow hover:bg-gray-600 focus:outline-none focus:ring focus:ring-gray-300">Kembali</a>
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        document.getElementById('btn-back').addEventListener('click', function() {
                            window.location.href = "/sponsor";
                        });
                        document.getElementById('btn-submitAdd').addEventListener('click', function(){
                            Swal.fire({
                                title: "Apakah Anda yakin ingin menambahkan data ini?",
                                text: "Data ini akan ditambahkan dan disimpan...",
                                icon: "question",
                                showCancelButton: true,
                                confirmButtonColor: "#3085d6",
                                cancelButtonColor: "#d33",
                                confirmButtonText: "Yes"
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    document.getElementById('form1').submit();
                                }
                            });
                        })
                    });
                </script>
            </form>
        </main>
    </div>
    
    <script>
    function previewImage() {
        const file = document.getElementById('url_image').files[0];
        const preview = document.getElementById('imagePreview');
        const reader = new FileReader();
        
        reader.onloadend = function () {
            preview.src = reader.result;
        }
        
        if (file) {
            reader.readAsDataURL(file);
        }
    }
    </script>
</body>
</html>
