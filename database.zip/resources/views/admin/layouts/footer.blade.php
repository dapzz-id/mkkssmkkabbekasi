<footer class="w-full py-6 mt-8 border-t border-slate-200/60 flex flex-col items-center justify-center gap-1.5 text-xs text-slate-500">
    <a href="https://instagram.com/raadeveloperz" target="_blank" rel="noopener noreferrer" class="inline-block transition-opacity hover:opacity-80">
        <img src="{{ asset('img/RPanel.png') }}"
             alt="RPanel Logo"
             class="h-7 sm:h-8 w-auto object-contain"
             title="Panel by raadeveloperz">
    </a>
    <p class="text-slate-500 m-0">
        &copy; 2024 Panel by
        <a href="https://instagram.com/raadeveloperz" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline font-semibold">raadeveloperz</a>
    </p>
</footer>