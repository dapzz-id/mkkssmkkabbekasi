@if (Auth::check())
    @php
        header("Location: /dashboard");
        exit();
    @endphp
@else
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>LOGIN | MKKS SMK BEKASI</title>
        <link rel="icon" href="{{ asset('img/ic_MKKS.png') }}" type="image/png">
        <link rel="icon" href="{{asset('img/ic_MKKS.ico')}}" type="image/x-icon">
        <link rel="stylesheet" href="{{asset('dist/css/main.css')}}">
        {{-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> --}}
        <style>
            body {
                background-color: #f8f9fa;
                height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
                margin: 0;
            }
            .card {
                width: 300px;
                padding: 20px;
                background-color: #5B5E61;
                color: #fff;
                border-radius: 10px;
                box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            }
            .card-title {
                text-align: center;
                font-size: 1.5em;
                margin-bottom: 20px;
            }
            .form-control {
                background-color: #8a8d8f;
                color: #fff;
                border: none;
                border-radius: 20px;
                padding: 10px 20px;
            }
            .form-control::placeholder {
                color: #d3d3d3;
            }
            .btn-login {
                width: 100%;
                background-color: #8a8d8f;
                border: none;
                color: #fff;
                font-weight: bold;
                border-radius: 20px;
                padding: 10px;
                margin-top: 10px;
            }
            .btn-login:hover {
                background-color: #75797c;
            }
        </style>
    </head>
    <body>
        <div class="bg-gray-500 rounded-xl w-96 min-h-80 p-5 flex flex-col justify-center items-center shadow-lg">
            <div class="bg-white w-full h-20 rounded-t-lg p-2 mb-4 flex flex-row justify-center items-center">
                <h5 class="text-gray-600 text-center font-bold text-xl mb-auto mt-auto">Login Admin</h5>
            </div>

            @if(session('LoginError'))
                <div class="w-full mb-3 p-2 bg-red-600/80 text-white text-sm rounded-lg text-center font-medium">
                    {{ session('LoginError') }}
                </div>
            @endif

            <form action="/login" method="POST" class="w-full flex flex-col items-center">
                @csrf
                <div class="mb-3 w-full">
                    <input class="p-2 w-full rounded-lg text-gray-900 @error('email') border-2 border-red-500 @enderror" type="email" id="email" name="email" placeholder="Email" required value="{{ old('email') }}">
                    @error("email")
                    <div class="text-red-300 text-xs mt-1">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
                <div class="mb-3 w-full">
                    <input class="p-2 w-full rounded-lg text-gray-900 @error('password') border-2 border-red-500 @enderror" type="password" id="password" name="password" placeholder="Password" required>
                    @error("password")
                    <div class="text-red-300 text-xs mt-1">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                {{-- Cloudflare Turnstile Protection --}}
                <x-turnstile action="login" theme="dark" />

                <button type="submit" class="btn btn-login">Login</button>
            </form>

            @if ($errors->any() || session('LoginError'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        setTimeout(function() {
                            if (window.turnstile) {
                                window.turnstile.reset('#turnstile-widget');
                            }
                        }, 500);
                    });
                </script>
            @endif
        </div>
    </body>
    </html>
@endif