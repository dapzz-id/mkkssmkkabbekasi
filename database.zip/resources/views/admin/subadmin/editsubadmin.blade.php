<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MKKS SMK BEKASI</title>
    <link rel="stylesheet" href="{{asset('dist/css/main.css')}}">
    <link rel="icon" href="{{ asset('img/ic_MKKS.png') }}" type="image/png">
    <link rel="icon" href="{{asset('img/ic_MKKS.ico')}}" type="image/x-icon">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <style>
            #content:hover, #content:hover svg {
                color: #2563eb;
            }
            *{
                outline: none;
                caret-color: transparent;
            }
        </style>
</head>
<body>
    <div class="bg-white w-full flex justify-between flex-wrap items-center py-4 text-center mb-3 border-b sticky top-0">
        <img src="{{asset('img/ic_MKKS.png')}}" class="w-auto h-12 ml-5" alt="">
        <h1 class="text-2xl font-bold">Edit Data Akses</h1>
        <div></div>
    </div>
    <div class="p-6 sm:p-12 lg:p-24 flex justify-center items-center">
        <main class="w-full max-w-lg bg-white shadow-md rounded-md p-6">
        
            @if(session('success'))
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    {{ session('success') }}
                </div>
            @endif
        
            <form action="{{ route('subadmin.update', $subAdmin->id) }}" id="form1" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="mb-4">
                    <label for="nama" class="block text-sm font-medium text-gray-700 flex flex-row">Nama<p class="text-red-500 font-bold">*</p></label>
                    <input type="text" class="mt-1 block w-full px-3 py-2 border caret-black border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200 @error('nama') border-red-500 @enderror" id="nama" name="name" value="{{ $subAdmin->name }}" required>
                    @error('nama')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="username" class="block text-sm font-medium text-gray-700 flex flex-row">Username<p class="text-red-500 font-bold">*</p></label>
                    <input type="text" class="mt-1 block w-full px-3 py-2 border caret-black border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200 @error('username') border-red-500 @enderror" id="username" name="username" value="{{ $subAdmin->username }}" required>
                    @error('username')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="email" class="block text-sm font-medium text-gray-700 flex flex-row">Email Address<p class="text-red-500 font-bold">*</p></label>
                    <input type="email" class="mt-1 block w-full px-3 py-2 border caret-black border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200 @error('email') border-red-500 @enderror" id="email" name="email" value="{{ $subAdmin->email }}" required>
                    @error('email')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>
        
                <div class="mb-4">
                    <label for="divisi" class="block text-sm font-medium text-gray-700 flex flex-row">Divisi<p class="text-red-500 font-bold">*</p></label>
                    <select class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200 @error('divisi') border-red-500 @enderror" id="divisi" name="divisi" required>
                        
                        <option value="" selected>Pilih Divisi</option>
                        @foreach($divisi as $item)
                            <option value="{{ $item->id }}" {{ $subAdmin->id_divisi == $item->id ? 'selected' : '' }}>
                                {{ $item->nama_divisi }}
                            </option>
                        @endforeach
                    </select>
                    @error('divisi')
                        @if ($message == 'validation.required')
                            <p class="text-red-500 text-xs mt-1">Divisi diperlukan!</p>
                        @endif
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="role" class="block text-sm font-medium text-gray-700 flex flex-row">Peran Sebagai<p class="text-red-500 font-bold">*</p></label>
                    <select class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200 @error('role') border-red-500 @enderror" id="role" name="role" required>
                        
                        <option value="" selected>Pilih Role</option>
                        <option value="admin" @if ($subAdmin->role == 'admin') selected @endif>Admin</option>
                        <option value="superadmin" @if ($subAdmin->role == 'superadmin') selected @endif>Super-Admin</option>
                    </select>
                    @error('role')
                        @if ($message == 'validation.required')
                            <p class="text-red-500 text-xs mt-1">Role diperlukan!</p>
                        @endif
                    @enderror
                </div>
                
                <div class="mb-4">
                    <label for="alamat" class="block text-sm font-medium text-gray-700 flex flex-row">Alamat<p class="text-red-500 font-bold">*</p></label>
                    <textarea name="alamat" id="alamat" class="mt-1 block w-full px-3 py-2 border caret-black border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200 @error('alamat') border-red-500 @enderror" cols="10" required>{{$subAdmin->alamat}}</textarea>
                    @error('alamat')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                    <input type="password" class="mt-1 block w-full px-3 py-2 border caret-black border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200 @error('password') border-red-500 @enderror" placeholder="Masukkan Password" id="password" name="password" value="">
                    @error('password')
                        @if ($message == 'validation.confirmed')
                            <p class="text-red-500 text-xs mt-1">Password tidak sama dengan yang bawah</p>
                        @else
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @endif
                    @enderror
                    <small class="text-gray-500">Biarkan kosong jika tidak ingin mengubah password.</small>
                </div>

                <div class="mb-4">
                    <label for="confirm_password" class="block text-sm font-medium text-gray-700">Konfirmasi Password</label>
                    <input type="password" class="mt-1 block w-full px-3 py-2 border caret-black border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200 @error('confirm_password') border-red-500 @enderror" placeholder="Konfirmasi Password" id="confirm_password" name="confirm_password" value="">
                    <p id="password-match-error" class="text-red-500 text-xs mt-1 hidden">Password tidak sama.</p>
                    @error('confirm_password')
                    @if ($message == 'validation.same')
                        <p class="text-red-500 text-xs mt-1">Password tidak sama dengan yang atas</p>
                    @else
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @endif
                    @enderror
                </div>

                
                <button type="button" id="btn-submitEdit" class="px-4 py-2 w-full bg-blue-500 text-white font-semibold rounded-md shadow hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300">Perbarui Akun</button>
                <a id="btn-back" class="mt-2 px-4 py-2 w-full block text-center bg-gray-500 cursor-pointer text-white font-semibold rounded-md shadow hover:bg-gray-600 focus:outline-none focus:ring focus:ring-gray-300">Kembali</a>

                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        const btnSubmitEdit = document.getElementById('btn-submitEdit');
                        const btnBack = document.getElementById('btn-back');
                
                        btnBack.addEventListener('click', function() {
                            window.location.href = "/manage/user"
                        });
                
                        btnSubmitEdit.addEventListener('click', function() {
                            Swal.fire({
                                title: "Apakah Anda yakin ingin mengedit data ini?",
                                text: "Data ini akan diupdate dan disimpan...",
                                icon: "question",
                                showCancelButton: true,
                                confirmButtonColor: "#3085d6",
                                cancelButtonColor: "#d33",
                                confirmButtonText: "Yes"
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    document.getElementById('form1').submit();
                                }
                            });
                        });
                    });
                </script>
            </form>
        </main>
    </div>
</body>
</html>