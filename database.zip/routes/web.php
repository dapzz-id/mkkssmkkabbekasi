<?php

use Illuminate\Support\Facades\Route;
use Filament\Facades\Filament;
use Illuminate\Http\Request;

use App\Http\Controllers\BerandaController;
use App\Http\Controllers\DivisiController;
use App\Http\Controllers\GaleriAdminController;
use App\Http\Controllers\GaleriController;
use App\Http\Controllers\KontenController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\PimpinanAdminController;
use App\Http\Controllers\SponsorController;
use App\Http\Controllers\SubAdminAdminController;
use App\Models\Calendar;
use App\Models\Konten;
use App\Models\Sponsor;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

// Route Publik

Route::get('/', [BerandaController::class, 'index']);
Route::get('/selengkapnya', [BerandaController::class, "selengkapnya"]);
Route::get('/divisi', [DivisiController::class, 'index']);
Route::get('/divisi/{divisi}', [DivisiController::class, 'show']);
Route::get('/divisi/{divisi}/{id_konten}', [KontenController::class, 'index']);
Route::get('/galeri', [GaleriController::class, 'index']);
Route::get('/selengkapnya', [BerandaController::class, 'selengkapnya']);
Route::get('/jadwal', [BerandaController::class, 'jadwal']);
Route::get('/konten/{id}', [KontenController::class, 'show'])->name('konten.show');


// Route Admin

Route::get('/login', function() {
    return view('admin.login.index');
})->name('login');
Route::post('/login', [LoginController::class, 'login'])->middleware('throttle:5,1');
Route::get('/logout', [LoginController::class, 'logout']);

Route::get('/gallery', function(Request $request) {
    $galleryPage = $request->input('gallery-page', 1);

    if(Auth::user()->role == 'admin'){
        $data = Konten::where('id_divisi', Auth::user()->id_divisi)->orderBy('id', 'desc')->paginate(10, ['*'], 'gallery-page', $galleryPage);
    }else if(Auth::user()->role == 'superadmin'){
        $data = Konten::orderBy('id', 'desc')->paginate(2, ['*'], 'gallery-page', $galleryPage);
    }

    if ($request->ajax()) {
        if ($request->has('gallery-page')) {
            return view('admin.gallery-table', compact('data'))->render();
        }
    } else {
        return view('admin.main.gallery', compact('data'))->render();
    }
})->name('gallery.main');

Route::get('/sponsor', function(Request $request){
    $sponsorPage = $request->input('sponsor-page', 1);
    $dataSponsor = Sponsor::orderBy('id', 'desc')->paginate(2, ['*'], 'sponsor-page', $sponsorPage);

    if ($request->ajax()) {
        if ($request->has('sponsor-page')) {
            return view('admin.sponsor-table', compact('dataSponsor'))->render();
        }
    } else {
        return view('admin.main.sponsor', compact('dataSponsor'))->render();
    }
});

Route::get('/manage/user', function(Request $request){
    $akunPage = $request->input('account-page', 1);
    $dataAkun = User::orderBy('id', 'desc')->paginate(4, ['*'], 'account-page', $akunPage);

    if ($request->ajax()) {
        if ($request->has('account-page')) {
            return view('admin.account-table', compact('dataAkun'))->render();
        }
    } else {
        return view('admin.main.account', compact('dataAkun'))->render();
    }
});

Route::get('/manage/event', function(Request $request){
    $calendarPage = $request->input('calendar-page', 1);
    $dataCalendar = Calendar::orderBy('id', 'desc')->paginate(4, ['*'], 'calendar-page', $calendarPage);

    if ($request->ajax()) {
        if ($request->has('calendar-page')) {
            return view('admin.calendar-table', compact('dataCalendar'))->render();
        }
    } else {
        return view('admin.main.calendar', compact('dataCalendar'))->render();
    }
});

Route::get('/dashboard', function(Request $request) {
    if (Auth::check()) {
        return view('admin.main.dashboard');
    } else {
        return redirect('/login');
    }
})->name('adm.dashboard');

Route::get('/subadmin', [SubAdminAdminController::class, "index"]);
Route::get('/subadmin/tambah', [SubAdminAdminController::class, "create"])->name('subadmin.create');
Route::get('/subadmin/edit/{id}', [SubAdminAdminController::class, "edit"]);
Route::put('/subadmin/edit/{id}', [SubAdminAdminController::class, "update"])->name('subadmin.update');
Route::delete('/subadmin/{id}', function($id) {
    $user = User::find($id);

    if ($user) {
        try {
            $user->delete();
            return response()->json(['status' => 'success']);
        } catch (\Exception $e) {
            return response()->json(['status' => 'error', 'message' => $e->getMessage()], 500);
        }
    } else {
        return response()->json(['status' => 'error', 'message' => 'User not found'], 404);
    }
})->name('subadmin.delete');

Route::post('/subadmin/tambah', [SubAdminAdminController::class, "store"]);

Route::get('/sponsor/tambah', [SponsorController::class, 'create'])->name('sponsor.create'); // Menampilkan form tambah sponsor
Route::post('/sponsor', [SponsorController::class, 'store'])->name('sponsor.store'); // Menyimpan sponsor baru

Route::get('/sponsor/edit/{id}', [SponsorController::class, 'edit'])->name('sponsor.edit'); // Menampilkan form edit sponsor
Route::put('/sponsor/{id}', [SponsorController::class, 'update'])->name('sponsor.update'); // Mengupdate data sponsor

Route::delete('/sponsor/{id}', [SponsorController::class, 'destroy'])->name('sponsor.destroy'); // Menghapus sponsor

// Route Pimpinan MKKS (Superadmin only)
Route::get('/pimpinan', [PimpinanAdminController::class, 'index'])->name('pimpinan.index');
Route::get('/pimpinan/tambah', [PimpinanAdminController::class, 'create'])->name('pimpinan.create');
Route::post('/pimpinan', [PimpinanAdminController::class, 'store'])->name('pimpinan.store');
Route::get('/pimpinan/edit/{id}', [PimpinanAdminController::class, 'edit'])->name('pimpinan.edit');
Route::put('/pimpinan/{id}', [PimpinanAdminController::class, 'update'])->name('pimpinan.update');
Route::delete('/pimpinan/{id}', [PimpinanAdminController::class, 'destroy'])->name('pimpinan.destroy');
Route::patch('/pimpinan/{id}/toggle-status', [PimpinanAdminController::class, 'toggleStatus'])->name('pimpinan.toggle');


Route::get('/galeri-kelola', [GaleriAdminController::class, 'index'])->name('galeri.index');
Route::get('/galeri-kelola/tambah', [GaleriAdminController::class, 'create'])->name('galeri.create');
Route::post('/galeri-kelola', [GaleriAdminController::class, 'store'])->name('galeri.store');
Route::get('/galeri-kelola/edit/{id}', [GaleriAdminController::class, 'edit'])->name('galeri.edit');
Route::put('/galeri-kelola/{id}', [GaleriAdminController::class, 'update'])->name('galeri.update');
Route::delete('/galeri-kelola/{id}', [GaleriAdminController::class, 'destroy'])->name('galeri.destroy');

Route::delete('/calendar/{id}', function($id) {
    $calendar = Calendar::find($id);

    if ($calendar) {
        try {
            $calendar->delete();
            return response()->json(['status' => 'success']);
        } catch (\Exception $e) {
            return response()->json(['status' => 'error', 'message' => 'Kesalahan Teknis, Coba Lagi. Jika masih berlanjut, hubungi admin segera...'], 500);
        }
    } else {
        return response()->json(['status' => 'error', 'message' => 'Kalender tidak ditemukan!'], 404);
    }
})->name('calendar.delete');

Route::post('/calendar', function(Request $request) {
    $request->validate([
        'name' => 'required|string|max:255',
        'date' => 'required|date',
    ], [
        'name.required' => 'Masukkan nama acara',
        'date.required' => 'Masukkan tanggal acara',
        'date.date' => 'Format tanggal tidak valid',
    ]);

    Calendar::create([
        'event_name' => $request->name,
        'event_date' => $request->date,
    ]);

    return redirect('/manage/event')->with('success', 'Data acara berhasil ditambahkan.');
})->name('calendar.store');

Route::get('/calendar/tambah', function() {
    return view('admin.calender.tambahcalendar');
})->name('calendar.create');

Route::get('/calendar/edit/{id}', function($id) {
    $calendar = Calendar::find($id);
    return view('admin.calender.editcalendar', compact('calendar'));
})->name('calendar.edit');

Route::put('/calendar/{id}', function(Request $request, $id) {
    $request->validate([
        'name' => 'required|string|max:255',
        'date' => 'required|date',
    ], [
        'name.required' => 'Masukkan nama acara',
        'date.required' => 'Masukkan tanggal acara',
        'date.date' => 'Format tanggal tidak valid',
    ]);

    $calendar = Calendar::find($id);

    if ($calendar) {
        $calendar->update([
            'event_name' => $request->name,
            'event_date' => $request->date,
        ]);

        return redirect('/manage/event')->with('success', 'Data acara berhasil diperbarui.');
    } else {
        return redirect('/manage/event')->with('error', 'Data acara tidak ditemukan.');
    }
})->name('calendar.update');
