<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, HasApiTokens, Notifiable;
    protected $table = 'user';
    protected $primaryKey = 'id';
    protected $fillable = [
        'id_divisi',
        'name',
        'username',
        'password',
        'role',
        'alamat',
        'email',
        'remember_token'
    ];

    public function divisi() {
        return $this->belongsTo(Divisi::class, 'id_divisi');
    }

    public function konten() {
        return $this->hasMany(Konten::class, 'id_user');
    }

}
