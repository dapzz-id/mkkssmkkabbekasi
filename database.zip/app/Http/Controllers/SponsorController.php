<?php

namespace App\Http\Controllers;

use App\Models\Sponsor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SponsorController extends Controller
{
    public function index() {
        $data = Sponsor::paginate(6);
        return view('admin.sponsor.datasponsor', [
            "data" => $data
        ]);
    }

    public function create() {
        return view('admin.sponsor.tambahsponsor');
    }

    public function store(Request $request)
    {
        // Validate the request data
        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'url_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048', // Adjust the max size as needed
        ], [
            'nama.required' => 'Masukkan nama sponsor',
            'url_image.required' => 'Unggah gambar sponsor',
            'url_image.image' => 'File yang diunggah harus berupa gambar',
            'url_image.mimes' => 'Gambar harus dalam format jpeg, png, jpg, gif, atau svg',
            'url_image.max' => 'Ukuran gambar tidak boleh lebih dari 2MiB',
        ]);

        // Handle the image upload
        $image = $request->file('url_image');

        if ($image) {
            $imageBase64 = base64_encode(file_get_contents($image->getRealPath()));

            Sponsor::create([
                'nama' => $request->nama,
                'url_image' => 'data:' . $image->getClientMimeType() . ';base64,' . $imageBase64,
            ]);
        }

        // Redirect to the sponsors list with a success message
        return redirect('/sponsor')->with('success', 'Sponsor berhasil ditambahkan.');
    }

    public function edit($id)
    {
        // Find sponsor by ID
        $sponsor = Sponsor::findOrFail($id);

        // Return the edit view with sponsor data
        return view('admin.sponsor.editsponsor', [
            'sponsor' => $sponsor
        ]);
    }

    public function update(Request $request, $id)
    {
        // Validate the request data
        $validatedData = $request->validate([
            'nama' => 'required|string|max:255',
            'url_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ], [
            'nama.required' => 'Masukkan nama sponsor',
            'url_image.image' => 'File yang diunggah harus berupa gambar',
            'url_image.mimes' => 'Gambar harus dalam format jpeg, png, jpg, gif, atau svg',
            'url_image.max' => 'Ukuran gambar tidak boleh lebih dari 2MiB',
        ]);

        // Find sponsor by ID
        $sponsor = Sponsor::findOrFail($id);

        // Update the sponsor data
        $sponsor->nama = $request->nama;

        // Handle image upload if a new image is provided
        if ($validatedData){
            if ($request->hasFile('url_image')) {
                $image = $request->file('url_image');
                $imageBase64 = base64_encode(file_get_contents($image->getRealPath()));
                $sponsor->url_image = 'data:' . $image->getClientMimeType() . ';base64,' . $imageBase64;
            }else{
                unset($sponsor->url_image);
            }
        }

        // Save the sponsor data
        $sponsor->save();

        // Redirect to the sponsors list with a success message
        return redirect('/sponsor')->with('success', 'Sponsor berhasil diperbarui.');
    }

    public function destroy($id)
    {
        $sponsor = Sponsor::find($id);

        if($sponsor){
            $sponsor->delete();
            return response()->json(['status' => 'success']);
        }else{
            return response()->json(['status' => 'error']);
        }
    }
}
