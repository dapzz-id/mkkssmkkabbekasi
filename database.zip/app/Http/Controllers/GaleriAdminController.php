<?php

namespace App\Http\Controllers;

use App\Models\Konten;
use App\Models\Divisi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;

class GaleriAdminController extends Controller
{
    public function index()
    {
        // $data = Konten::with('divisi')->paginate(10);
        // return view('admin.dashboard', compact('data'));

        if(Auth::user()->role == 'admin'){
            $data = Konten::where('id_divisi', Auth::user()->id_divisi)->with('divisi')->paginate(10);
        }else if(Auth::user()->role == 'superadmin'){
            $data = Konten::with('divisi')->paginate(10);
        }
        return view('admin.dashboard', compact('data'));

    }

    public function create()
    {
        $divisi = Divisi::all();
        return view('admin.galeri.tambahgaleri', compact('divisi'));
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'id_divisi' => 'required|exists:divisi,id',
            'judul' => 'required|string|max:255',
            'deskripsi' => 'required',
            'media' => 'required|array|min:1',
            'media.*' => 'file|mimes:jpeg,png,jpg,mp4|max:35840',
        ], [
            'id_divisi.required' => 'Pilih divisi',
            'judul.required' => 'Masukkan judul',
            'deskripsi.required' => 'Masukkan deskripsi',
            'media.required' => 'Unggah setidaknya satu media',
            'media.*.file' => 'File yang diunggah harus berupa file',
            'media.*.mimes' => 'Media harus dalam format jpeg, png, jpg, mp4',
            'media.*.max' => 'Ukuran media tidak boleh lebih dari 35MiB',
        ]);

        if (Auth::user()->role == 'admin') {
            $validatedData['id_divisi'] = Auth::user()->id_divisi;
        }

        $urls = [];
        if ($request->hasFile('media')) {
            foreach ($request->file('media') as $file) {
                $path = $file->store('media', 'public');
                $urls[] = '/public' . Storage::url($path);
            }
        }

        $validatedData['url_media'] = json_encode($urls);
        $validatedData['id_user'] = Auth::user()->id;
        $validatedData['tanggal_upload'] = now();

        Konten::create($validatedData);

        return redirect('/gallery')->with('success', 'Data galeri berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $galeri = Konten::find($id);
        $divisi = Divisi::all();

        if ($galeri && $divisi){
            return view('admin.galeri.editgaleri', compact('galeri', 'divisi'));
        }

    }

    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'id_divisi' => 'required|exists:divisi,id',
            'judul' => 'required|string|max:255',
            'deskripsi' => 'required',
            'media' => 'sometimes|array',
            'media.*' => 'file|mimes:jpeg,png,jpg,mp4|max:35840',
        ], [
            'id_divisi.required' => 'Pilih divisi',
            'judul.required' => 'Masukkan judul',
            'deskripsi.required' => 'Masukkan deskripsi',
            'media.*.file' => 'File yang diunggah harus berupa file',
            'media.*.mimes' => 'Media harus dalam format jpeg, png, jpg, mp4',
            'media.*.max' => 'Ukuran media tidak boleh lebih dari 35MiB',
        ]);

        if (Auth::user()->role == 'admin') {
            $validatedData['id_divisi'] = Auth::user()->id_divisi;
        }

        $galeri = Konten::findOrFail($id);

        if ($request->hasFile('media')) {
            // Delete old media files
            $oldMedia = json_decode($galeri->url_media, true) ?? [];
            foreach ($oldMedia as $oldUrl) {
                $path = str_replace('/storage/', '', $oldUrl);
                Storage::disk('public')->delete($path);
            }

            $urls = [];
            foreach ($request->file('media') as $file) {
                $path = $file->store('media', 'public');
                $urls[] = '/public' . Storage::url($path);
            }
            $validatedData['url_media'] = json_encode($urls);
        }

        $galeri->update($validatedData);

        return redirect('/gallery')->with('success', 'Data galeri berhasil diperbarui.');
    }

    public function destroy($id)
    {
        $galeri = Konten::find($id);

        if($galeri){
            // Delete associated media files
            $oldMedia = json_decode($galeri->url_media, true) ?? [];
            foreach ($oldMedia as $oldUrl) {
                $path = str_replace('/storage/', '', $oldUrl);
                Storage::disk('public')->delete($path);
            }
            $galeri->delete();
            return response()->json(['status' => 'success']);
        }else{
            return response()->json(['status' => 'error']);
        }
    }
}