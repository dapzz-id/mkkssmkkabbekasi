<?php

namespace App\Http\Controllers;

use App\Models\Divisi;
use App\Models\Konten;
use App\Models\Sponsor;
use Illuminate\Http\Request;

class KontenController extends Controller
{
    public function index($divisi, $id_divisi) {
        $konten = Konten::where('id', $id_divisi)->get()[0];

        return view('publik.detailkonten', [
            'konten' => $konten,
            'divisiKonten' => $divisi,
            "divisi" => Divisi::all(),
            'sponsor' => Sponsor::all()
        ]);
    }

    public function show($id)
    {
        $konten = Konten::with('divisi')->findOrFail($id);
        $divisiKonten = $konten->divisi->nama_divisi;
        $divisi = Divisi::all();

        return view('publik.detailkonten', compact('konten', 'divisiKonten', 'divisi'));
    }
}
