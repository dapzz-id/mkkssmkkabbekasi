<?php

namespace App\Http\Controllers;

use App\Models\Pimpinan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class PimpinanAdminController extends Controller
{
    /**
     * Ensure only Superadmin can access Pimpinan management.
     */
    protected function authorizeSuperAdmin(): void
    {
        if (!Auth::check() || Auth::user()->role !== 'superadmin') {
            abort(403, 'Akses ditolak. Halaman ini hanya untuk Superadmin.');
        }
    }

    /**
     * Display a listing of Pimpinan MKKS.
     */
    public function index(Request $request)
    {
        $this->authorizeSuperAdmin();

        $page = $request->input('pimpinan-page', 1);
        $dataPimpinan = Pimpinan::ordered()->paginate(6, ['*'], 'pimpinan-page', $page);

        if ($request->ajax()) {
            if ($request->has('pimpinan-page')) {
                return view('admin.pimpinan-table', compact('dataPimpinan'))->render();
            }
        }

        return view('admin.main.pimpinan', compact('dataPimpinan'));
    }

    /**
     * Show the form for creating a new Pimpinan.
     */
    public function create()
    {
        $this->authorizeSuperAdmin();

        // Suggest the next order number automatically
        $nextOrder = (Pimpinan::max('urutan') ?? 0) + 1;

        return view('admin.pimpinan.tambahpimpinan', compact('nextOrder'));
    }

    /**
     * Store a newly created Pimpinan in storage.
     */
    public function store(Request $request)
    {
        $this->authorizeSuperAdmin();

        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'jabatan' => 'required|string|max:255',
            'foto' => 'required|image|mimes:jpeg,png,jpg,webp|max:2048',
            'urutan' => 'nullable|integer|min:0',
            'is_active' => 'nullable|in:0,1',
        ], [
            'nama.required' => 'Masukkan nama pimpinan',
            'jabatan.required' => 'Masukkan jabatan pimpinan',
            'foto.required' => 'Unggah foto pimpinan',
            'foto.image' => 'File harus berupa gambar',
            'foto.mimes' => 'Format gambar harus jpeg, png, jpg, atau webp',
            'foto.max' => 'Ukuran gambar maksimal 2MB',
        ]);

        $path = $request->file('foto')->store('pimpinan', 'public');

        Pimpinan::create([
            'nama' => trim($validated['nama']),
            'jabatan' => trim($validated['jabatan']),
            'foto' => '/storage/' . $path,
            'urutan' => $validated['urutan'] ?? ((Pimpinan::max('urutan') ?? 0) + 1),
            'is_active' => $request->has('is_active') ? (bool) $request->input('is_active') : true,
        ]);

        session()->flash('success', 'Data pimpinan berhasil ditambahkan.');

        if ($request->ajax() || $request->wantsJson()) {
            return response()->json([
                'status' => 'success',
                'message' => 'Data pimpinan berhasil ditambahkan.',
                'redirect' => url('/pimpinan')
            ]);
        }

        return redirect('/pimpinan');
    }

    /**
     * Show the form for editing the specified Pimpinan.
     */
    public function edit($id)
    {
        $this->authorizeSuperAdmin();

        $pimpinan = Pimpinan::findOrFail($id);

        return view('admin.pimpinan.editpimpinan', compact('pimpinan'));
    }

    /**
     * Update the specified Pimpinan in storage.
     */
    public function update(Request $request, $id)
    {
        $this->authorizeSuperAdmin();

        $pimpinan = Pimpinan::findOrFail($id);

        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'jabatan' => 'required|string|max:255',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
            'urutan' => 'nullable|integer|min:0',
            'is_active' => 'nullable|in:0,1',
        ], [
            'nama.required' => 'Masukkan nama pimpinan',
            'jabatan.required' => 'Masukkan jabatan pimpinan',
            'foto.image' => 'File harus berupa gambar',
            'foto.mimes' => 'Format gambar harus jpeg, png, jpg, atau webp',
            'foto.max' => 'Ukuran gambar maksimal 2MB',
        ]);

        $dataToUpdate = [
            'nama' => trim($validated['nama']),
            'jabatan' => trim($validated['jabatan']),
            'urutan' => $validated['urutan'] ?? $pimpinan->urutan,
            'is_active' => $request->has('is_active') ? (bool) $request->input('is_active') : false,
        ];

        $newPath = null;
        $oldPhotoToDelete = null;

        if ($request->hasFile('foto')) {
            // 1. Store new photo first
            $newPath = $request->file('foto')->store('pimpinan', 'public');
            $dataToUpdate['foto'] = '/storage/' . $newPath;

            // 2. Queue old photo to be deleted ONLY after successful update
            $oldPhotoToDelete = str_replace('/storage/', '', $pimpinan->foto);
        }

        try {
            // 3. Update database record
            $pimpinan->update($dataToUpdate);

            // 4. Confirm success: delete old photo from storage
            if ($oldPhotoToDelete && !empty($oldPhotoToDelete) && Storage::disk('public')->exists($oldPhotoToDelete)) {
                Storage::disk('public')->delete($oldPhotoToDelete);
            }
        } catch (\Throwable $e) {
            // Rollback new file if DB update failed
            if ($newPath && Storage::disk('public')->exists($newPath)) {
                Storage::disk('public')->delete($newPath);
            }
            throw $e;
        }

        session()->flash('success', 'Data pimpinan berhasil diperbarui.');

        if ($request->ajax() || $request->wantsJson()) {
            return response()->json([
                'status' => 'success',
                'message' => 'Data pimpinan berhasil diperbarui.',
                'redirect' => url('/pimpinan')
            ]);
        }

        return redirect('/pimpinan');
    }

    /**
     * Remove the specified Pimpinan from storage.
     */
    public function destroy($id)
    {
        $this->authorizeSuperAdmin();

        $pimpinan = Pimpinan::find($id);

        if (!$pimpinan) {
            return response()->json(['status' => 'error', 'message' => 'Pimpinan tidak ditemukan'], 404);
        }

        try {
            // Delete photo file if present on storage disk
            $filePath = str_replace('/storage/', '', $pimpinan->foto);
            if (!empty($filePath) && Storage::disk('public')->exists($filePath)) {
                Storage::disk('public')->delete($filePath);
            }

            $pimpinan->delete();
            return response()->json(['status' => 'success']);
        } catch (\Throwable $e) {
            return response()->json(['status' => 'error', 'message' => 'Gagal menghapus data: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Toggle the active status of a Pimpinan.
     */
    public function toggleStatus($id)
    {
        $this->authorizeSuperAdmin();

        $pimpinan = Pimpinan::findOrFail($id);
        $pimpinan->is_active = !$pimpinan->is_active;
        $pimpinan->save();

        return response()->json([
            'status' => 'success',
            'is_active' => $pimpinan->is_active,
            'message' => 'Status pimpinan berhasil diubah.'
        ]);
    }
}
